# nguyensang > 2024-09-15 3:19am
https://universe.roboflow.com/sang-oacf6/nguyensang

Provided by a Roboflow user
License: CC BY 4.0

